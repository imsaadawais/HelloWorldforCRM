﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebApiHW.Models;
using WebApiHW.Services;

namespace WebApiHW.Controllers
{
    public class HelloController : ApiController
    {
        private HomeRepository homeRepository;

        public HelloController()
        {
            this.homeRepository = new HomeRepository();
        } 
        public Models.Hello Get()
        {
            return homeRepository.HelloWorld();
        }

        //public string[] Get()
        //{
        //    return new string[]
        //{
        //     "Hello",
        //     "World"
        //};
        //}

    }
}
