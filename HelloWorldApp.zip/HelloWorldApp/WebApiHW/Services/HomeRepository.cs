﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApiHW.Models;

namespace WebApiHW.Services
{
    public class HomeRepository
    {
        public Hello HelloWorld()
        {
            Hello obj = new Hello();
            obj.Name = "Hello World";
            return obj;
        }
       
    }
}