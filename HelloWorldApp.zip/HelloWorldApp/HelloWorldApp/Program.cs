﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WebApiHW.Services;

namespace HelloWorldApp
{
    abstract class HelloWorldBase
    {
        public abstract void writeHelloWorld();
    }
    class HelloWorld : HelloWorldBase
    {
        private HomeRepository repository;

        public override void writeHelloWorld()
        {
            
          
            this.repository = new HomeRepository();

            string container = repository.HelloWorld().Name;
            Console.WriteLine(container);
            Console.Read();
        }
    }
    class HelloWorldApp
    {
        static void Main()
        {
            HelloWorldBase hwb = new HelloWorld();
            hwb.writeHelloWorld();
        }
    }
}
